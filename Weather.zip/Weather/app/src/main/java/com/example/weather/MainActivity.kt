package com.example.weather

import android.os.AsyncTask
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.*
import org.json.JSONObject
import java.lang.Exception
import java.net.URL
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {

    /* Enter the state and country here */
    val CITY: String = "New York, US"
    /* Your Api Key */
    val API: String = "79463103bc09d3febb75601b7f734b76"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        weather().execute()
    }

    // Class
    inner class weather(): AsyncTask<String, Void, String>() {
        /* This code executes as soon as the app is launched */
        override fun onPreExecute() {
            super.onPreExecute()
            findViewById<ProgressBar>(R.id.loadBar).visibility = View.VISIBLE
            findViewById<RelativeLayout>(R.id.mainLayout).visibility = View.GONE
            findViewById<TextView>(R.id.errorText).visibility = View.GONE
        }

        /* This code is for the background Process */
        override fun doInBackground(vararg p0: String?): String? {
            var response:String?
            try{
                response = URL("https://api.openweathermap.org/data/2.5/weather?q=$CITY&units=imperial&appid=$API").readText(
                    Charsets.UTF_8
                )
            }
            catch (e: Exception) {
                response = null
            }
            return response
        }

        /* This code executes when the loading is complete */
        override fun onPostExecute(result: String?) {
            super.onPostExecute(result)
            try {
                /* Extracting information from the API */
                val jsonObj = JSONObject(result)
                val main = jsonObj.getJSONObject("main")
                val sys = jsonObj.getJSONObject("sys")
                val wind = jsonObj.getJSONObject("wind")
                val weather = jsonObj.getJSONArray("weather").getJSONObject(0)

                val updatedAt:Long = jsonObj.getLong("dt")
                val updatedAtText = "Updated at: "+ SimpleDateFormat("MM/dd/yyyy hh:mm a", Locale.ENGLISH).format(Date(updatedAt*1000))
                val temp = main.getString("temp")+"°F"
                val tempMin = "Min Temp: " + main.getString("temp_min")+"°F"
                val tempMax = "Max Temp: " + main.getString("temp_max")+"°F"
                val humidity = main.getString("humidity")

                val sunrise:Long = sys.getLong("sunrise")
                val sunset:Long = sys.getLong("sunset")
                val windSpeed = wind.getString("speed")
                val weatherDescription = weather.getString("description")

                val address = jsonObj.getString("name")+", "+sys.getString("country")

                /* Displaying information that was extracted to each Text View */
                findViewById<TextView>(R.id.address).text = address
                findViewById<TextView>(R.id.updatedAt).text = updatedAtText
                findViewById<TextView>(R.id.status).text = weatherDescription.uppercase()
                findViewById<TextView>(R.id.temp).text = temp
                findViewById<TextView>(R.id.temp_min).text = tempMin
                findViewById<TextView>(R.id.temp_max).text = tempMax
                findViewById<TextView>(R.id.sunrise).text = SimpleDateFormat("hh:mm a", Locale.ENGLISH).format(Date(sunrise*1000))
                findViewById<TextView>(R.id.sunset).text = SimpleDateFormat("hh:mm a", Locale.ENGLISH).format(Date(sunset*1000))
                findViewById<TextView>(R.id.wind).text = "$windSpeed MPH"
                findViewById<TextView>(R.id.humidity).text = "$humidity%"

                /* Progress Bar is hidden when the app is working */
                findViewById<ProgressBar>(R.id.loadBar).visibility = View.GONE
                findViewById<RelativeLayout>(R.id.mainLayout).visibility = View.VISIBLE
            }
            /* This executes when the code above has any issues */
            catch (e: Exception) {
                findViewById<ProgressBar>(R.id.loadBar).visibility = View.GONE
                findViewById<TextView>(R.id.errorText).visibility = View.VISIBLE
            }
        }
    }
}